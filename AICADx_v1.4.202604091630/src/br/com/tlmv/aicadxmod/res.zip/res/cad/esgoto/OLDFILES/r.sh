#!/bin/sh
/usr/bin/ffmpeg -i $1.bmp $1.jpg

